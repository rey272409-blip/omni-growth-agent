import json

FILE = "memory.json"

def load():
    try:
        return json.load(open(FILE))
    except:
        return []

def save(data):
    json.dump(data, open(FILE, "w"), indent=2)
