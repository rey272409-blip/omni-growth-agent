from core.llm import call_llm

def get_trends(niche):
    return call_llm(
        "你是数据分析专家",
        f"分析当前{niche}热门话题（适合短视频/小红书）"
    )
