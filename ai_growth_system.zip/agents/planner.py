from core.llm import call_llm

def plan(goal):
    return call_llm(
        "你是运营总监",
        f"拆解目标：{goal}，输出执行步骤"
    )
