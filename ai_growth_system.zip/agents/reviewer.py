from core.llm import call_llm

def review(content):
    return call_llm(
        "你是内容审核官",
        f"优化并提升质量：{content}"
    )
