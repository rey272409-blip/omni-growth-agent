from core.llm import call_llm

def make_strategy(trends):
    return call_llm(
        "你是增长专家",
        f"基于这些热点生成爆款选题：{trends}"
    )
