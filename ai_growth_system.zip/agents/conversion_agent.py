from core.llm import call_llm

def optimize_conversion(content):
    return call_llm(
        "你是营销专家",
        f"优化这个内容，让用户更容易转化（关注/购买）：{content}"
    )
