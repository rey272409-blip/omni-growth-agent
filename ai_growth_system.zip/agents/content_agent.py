from core.llm import call_llm

def create_content(topic):
    return call_llm(
        "你是爆款文案专家",
        f"写一个短视频/小红书内容：{topic}"
    )
