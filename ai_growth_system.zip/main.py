from agents.planner import plan
from agents.data_agent import get_trends
from agents.strategy_agent import make_strategy
from agents.content_agent import create_content
from agents.conversion_agent import optimize_conversion
from agents.reviewer import review
from core.memory import load, save

def run(goal, niche):
    print("🎯 目标:", goal)

    p = plan(goal)
    print("\n📌 计划:", p)

    trends = get_trends(niche)
    print("\n🔥 热点:", trends)

    strategy = make_strategy(trends)
    print("\n🧠 选题:", strategy)

    content = create_content(strategy)
    print("\n✍️ 内容:", content)

    monetized = optimize_conversion(content)
    print("\n💰 转化:", monetized)

    final = review(monetized)
    print("\n✅ 最终:", final)

    mem = load()
    mem.append({"goal": goal, "result": final})
    save(mem)

if __name__ == "__main__":
    goal = "做一个能赚钱的自媒体账号"
    niche = "AI副业"
    run(goal, niche)
