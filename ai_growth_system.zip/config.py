OPENAI_API_KEY = "your_api_key"
MODEL = "gpt-5.3"
